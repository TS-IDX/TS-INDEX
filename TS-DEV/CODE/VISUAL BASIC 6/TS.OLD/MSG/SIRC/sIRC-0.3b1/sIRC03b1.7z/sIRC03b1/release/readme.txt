sIRC v0.3 BETA 1

Commands

/raw [raw-commands]
/msg [nickname] or [nickserv]
/whois [nickname]
/server [ircserver] [port]
/j #[channel]
/part
/nick [nickname]

Changelog

v0.1

&File.Connect
&File.Disconnect
&Window
&About

v0.2

added &View.Colors... (colors.ini)
added &File.Connect.Port
added &Help.Contents
added &Help.About sIRC...
added command /server
redesigned forms

v0.3

minimize to systray
&Favorites (servers.ini) listbox database write to textfile / database textfile
&Commands (like op, ban, kick etc.)
&Tools.Options...
&File.Select Server...
&File.Select Server... listbox from textfile servers.ini

v0.4

&File.New Window load same form frequently times
&Tools.Log Files...
&Timestamp

v0.5

XDCC

� 2015 by Thomas Schilb | thomas.schilb@live.de