﻿<div align="center">

## Calculate MD5


</div>

### Description

This code calculates the MD5 hash of an input message. The code is not mine, it's a part of a submission by Joseph Smugeresky. However, since it's the only working code I could found without the need of DLLs, I'm submitting it right here.

Using it is really easy:

Hash = CalculateMD5(InputMessage)
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2003-05-14 02:41:02
**By**             |[Mark van Cuijk](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/mark-van-cuijk.md)
**Level**          |Intermediate
**User Rating**    |4.6 (64 globes from 14 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Encryption](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/encryption__1-48.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Calculate\_1587485142003\.zip](https://github.com/Planet-Source-Code/mark-van-cuijk-calculate-md5__1-41067/archive/master.zip)








