﻿<div align="center">

## Encrypter/Decryptor


</div>

### Description

This code mainly used to encrypt large amount of data files . you can select a file & the destination path of it with the help of common dialog box.and then it encrypt the data. in the same way you can decrypt the file also. you can encrypt any type of file like .txt,.doc,.mdb any.........it's a very powerful encryption/decryption software. trust me.........
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2004-05-08 17:32:30
**By**             |[Anuj sharrma](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/anuj-sharrma.md)
**Level**          |Beginner
**User Rating**    |4.4 (53 globes from 12 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Encryption](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/encryption__1-48.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Encrypter\_174310582004\.zip](https://github.com/Planet-Source-Code/anuj-sharrma-encrypter-decryptor__1-53651/archive/master.zip)








