hi user, 
It's a good program for encryption/decryption. filesize does not matter for this.
this program is free for every-one. 

for any comments-anujsharrma@yahoo.com