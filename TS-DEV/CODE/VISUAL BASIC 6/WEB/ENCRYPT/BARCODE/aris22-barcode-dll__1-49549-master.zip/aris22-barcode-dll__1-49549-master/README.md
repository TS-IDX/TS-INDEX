﻿<div align="center">

## Barcode DLL


</div>

### Description

Code128,Code39,EAN13,EAN8 Barcode Generator DLL.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2003-10-31 01:00:26
**By**             |[Aris22](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/aris22.md)
**Level**          |Beginner
**User Rating**    |4.4 (57 globes from 13 users)
**Compatibility**  |VB 6\.0
**Category**       |[OLE/ COM/ DCOM/ Active\-X](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/ole-com-dcom-active-x__1-29.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Barcode\_DL16651110312003\.zip](https://github.com/Planet-Source-Code/aris22-barcode-dll__1-49549/archive/master.zip)








