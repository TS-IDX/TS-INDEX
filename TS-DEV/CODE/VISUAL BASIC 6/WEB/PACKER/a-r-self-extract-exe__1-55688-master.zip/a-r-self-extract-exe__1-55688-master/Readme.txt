this project includes 2 parts:

	1. the file manager: arange the files you want to pack into the exe,
	set the "autorun": the file that will be execute after the unpack is complete,
	compile the exe.
	2. the extractor: the project that it's exe will be the unpacker. the files
	would be packed in it.

compile the 2 projects, and put them in the same dir, and all you need to do next, is
run the file manager.

good luck (;