﻿<div align="center">

## Virtual Aquarium


</div>

### Description

It revives my old program that had around 2 Millions of user in the world.

Now for Windows XP with VB open source. Use your desktop as background
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2006-04-12 05:34:56
**By**             |[Agustin Rodriguez](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/agustin-rodriguez.md)
**Level**          |Intermediate
**User Rating**    |4.9 (59 globes from 12 users)
**Compatibility**  |VB 6\.0
**Category**       |[Complete Applications](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/complete-applications__1-27.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Virtual\_Aq1986744132006\.zip](https://github.com/Planet-Source-Code/agustin-rodriguez-virtual-aquarium__1-64997/archive/master.zip)








