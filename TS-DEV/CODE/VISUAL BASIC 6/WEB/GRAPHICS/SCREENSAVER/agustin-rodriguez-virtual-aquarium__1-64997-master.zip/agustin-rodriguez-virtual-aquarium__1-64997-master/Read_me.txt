3D Virtual Aquarium revives my old program that had around 2 Millions of user in the world.
Now for Windows XP with VB open source. Use your desktop as background.