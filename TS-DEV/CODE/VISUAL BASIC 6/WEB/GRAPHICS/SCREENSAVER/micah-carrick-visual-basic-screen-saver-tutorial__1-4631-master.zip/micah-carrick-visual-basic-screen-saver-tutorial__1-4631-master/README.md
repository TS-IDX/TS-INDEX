﻿<div align="center">

## Visual Basic Screen Saver Tutorial


</div>

### Description

Visual Basic Screen Saver walks you through the process of building a screen saver in VB as well as explaining why. From setting up the project to knowing what parameters are passed to a screensaver at run time. Includes the tutorial in windows .hlp format as well as complete screensaver source code.

[notes added 4.20.2005]

This is old... like 1999 old. Also, The HTML version is at http://www.micahcarrick.com/v2/content/view/10/3/

I hear it doesn't work in XP. Anybody know why?
 
### More Info
 
This is for anyone who is a beginner at making screen savers, as it does not get into the more complex tasks of preview and high end graphics. Anyone curious as to how to make thier own saver.


<span>             |<span>
---                |---
**Submitted On**   |1999-07-06 10:13:58
**By**             |[Micah Carrick](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/micah-carrick.md)
**Level**          |Beginner
**User Rating**    |4.3 (56 globes from 13 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Complete Applications](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/complete-applications__1-27.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[CODE\_UPLOAD1990\.zip](https://github.com/Planet-Source-Code/micah-carrick-visual-basic-screen-saver-tutorial__1-4631/archive/master.zip)








