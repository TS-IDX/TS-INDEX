
-------------------------------------------------------------------
   Micah Carrick's Visual Basic Screen Savers Tutorial Version 1.1
-------------------------------------------------------------------
Welcome. This is a tutorial to guide you through the proccess
of making a screen saver in Visual Basic Step-By-Step.

Click VBSaver.hlp to get started. All source code is included 
in the source code folder.

New in Version 1.1 -
  Fixed two typos in source code.
  Fixed one typo in HLP file.

-------------------------------------------------------------------
�1999 Micah Carrick - micah@carrick.com - http://micah.carrick.com
This tutorial is available in HTML format at www.computergeekz.net