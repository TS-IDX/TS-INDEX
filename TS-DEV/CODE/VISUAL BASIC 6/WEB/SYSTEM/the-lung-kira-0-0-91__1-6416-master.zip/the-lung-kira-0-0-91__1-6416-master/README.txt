Compiling

Cmos.bas > First Basic
Cpu.c    > Lcc 3.1
Kira     > VC++ 6


Locations

Cmos.exe > app dir
Cpu.dll  > win sys
Kira.dll > win sys