﻿<div align="center">

## Kira \- 0\.0\.91


</div>

### Description

Includes (with source), c++ kira.dll for global mouse hook, c cpu.dll for cpuid/ cpuid_avail/ cycles_elapsed, basic cmos.exe for accessing cmos in 9x+/Nt+ , 

----

Heres what kira has/does/shows 

----

Cmos Contents Viewer, Comp/User Changer, CPUID, Dir Locations, DiskSpace, dVolumeInfo, Display Settings, Errors (All WinErr Const/Desc/Name), File Attrib, File Time (Get/Set), Get Ip/Host, ICMP Stats, Icon Info, Icon Settings, Ie Cache/History Viewer, Ie Options, IP Stats, KeybInfo, KeybSettings, Menu Settings, Monitor Info, Mouse Info, MouseMov (Global Mouse Hook), MouseWarp (GMH), Mpeg Info/Tag Editor, Network Info, Performance Monitor (9x), Ping, Power Status, Processor Info, Registration Info, StringFileInfo Editor 16/32bit, Shared Files, Sticky Keys, TCP Stats, UDP Stats, Up Time, Window Info, Window Killer (PopUp Banner Killer), Windows (Set A Windows Properties), Windows Info (OS).
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2000-06-05 00:05:12
**By**             |[The\_Lung](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/the-lung.md)
**Level**          |Advanced
**User Rating**    |4.8 (57 globes from 12 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Complete Applications](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/complete-applications__1-27.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[CODE\_UPLOAD6436652000\.zip](https://github.com/Planet-Source-Code/the-lung-kira-0-0-91__1-6416/archive/master.zip)








