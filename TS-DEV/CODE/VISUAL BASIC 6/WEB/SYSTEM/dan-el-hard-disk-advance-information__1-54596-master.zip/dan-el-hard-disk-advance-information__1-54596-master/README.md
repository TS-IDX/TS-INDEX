﻿<div align="center">

## Hard Disk Advance Information


</div>

### Description

Show Name, Model, Firmware, Graph Space Disk, Serial Number,etc....
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2004-06-25 22:19:52
**By**             |[dan\!el](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/dan-el.md)
**Level**          |Advanced
**User Rating**    |4.8 (58 globes from 12 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Coding Standards](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/coding-standards__1-43.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Hard\_Disk\_1762176262004\.zip](https://github.com/Planet-Source-Code/dan-el-hard-disk-advance-information__1-54596/archive/master.zip)








