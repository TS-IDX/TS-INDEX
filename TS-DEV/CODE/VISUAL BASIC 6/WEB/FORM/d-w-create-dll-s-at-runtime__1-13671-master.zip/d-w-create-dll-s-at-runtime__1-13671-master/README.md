﻿<div align="center">

## Create Dll's at Runtime


</div>

### Description

Here is a VB wrapper for RC.exe, the DOS resource file

compiler, that allows you to put a .dll into a resource

file and compile it into an executable making it more or

less stand-alone. Included is a useful sample project

that contains a .dll and some code written by Catalin

Petolea (Mancubus), birkhoffs@hotmail.com. This sample

shows how to create the dll in the Form_Load from the

.exe and also has a CPU information module that can very

easily be dropped into any project. It returns a concise

string containing most information on CPU's.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2000-12-18 13:05:36
**By**             |[D\.W\.](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/d-w.md)
**Level**          |Intermediate
**User Rating**    |4.8 (58 globes from 12 users)
**Compatibility**  |VB 6\.0
**Category**       |[VB function enhancement](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/vb-function-enhancement__1-25.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[CODE\_UPLOAD1280812182000\.zip](https://github.com/Planet-Source-Code/d-w-create-dll-s-at-runtime__1-13671/archive/master.zip)








