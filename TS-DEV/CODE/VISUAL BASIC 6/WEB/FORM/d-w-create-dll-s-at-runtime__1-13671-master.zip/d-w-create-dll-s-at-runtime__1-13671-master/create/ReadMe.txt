Here is a VB wrapper for RC.exe, the DOS resource file 
compiler, that allows you to put a .dll into a resource 
file and compile it into an executable making it more or 
less stand-alone. Included is a useful sample project 
that contains a .dll and some code written by Catalin 
Petolea (Mancubus), birkhoffs@hotmail.com. This sample 
shows how to create the dll in the Form_Load from the 
.exe and also has a CPU information module that can very
easily be dropped into any project. It returns a concise
string containing most information on CPU's.