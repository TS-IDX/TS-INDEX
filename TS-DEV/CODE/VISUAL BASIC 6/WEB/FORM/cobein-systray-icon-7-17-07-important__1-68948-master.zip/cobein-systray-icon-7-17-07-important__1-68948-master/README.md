﻿<div align="center">

## Systray Icon \(7\-17\-07 IMPORTANT\)


</div>

### Description

Reuploaded, last post is not accessible ??? I found a big bug concerning the recovery function now is working right, please if you are using and old version replace it. Major rewrite, additions and bug fixes, added support for windowless projects, class arrays windows 9x balloon, 3 new methods to load icons from resource files, from files and to extract them from dlls, exes. Fixed the balloontimeout and problems with popup menus. Better examples, add no window example, and multiple icons.

Ive seen a lot of systray icon codes around here, but this one have everything, all the events including balloon close and balloon click all the properties you need to customize it, and a recovery function that ensure the icon will be shown even after an explorer crash, and is all in single class ready to be added to your projects, it uses LaVolpe and Paul Caton self subclass and callback. Updated: Added balloon timeout/nosound, fix some bugs and modified the recovery function Enjoy it!
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2007-07-22 22:14:32
**By**             |[Cobein](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/cobein.md)
**Level**          |Beginner
**User Rating**    |4.7 (56 globes from 12 users)
**Compatibility**  |VB 6\.0
**Category**       |[Custom Controls/ Forms/  Menus](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/custom-controls-forms-menus__1-4.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Systray\_Ic2076807232007\.zip](https://github.com/Planet-Source-Code/cobein-systray-icon-7-17-07-important__1-68948/archive/master.zip)








