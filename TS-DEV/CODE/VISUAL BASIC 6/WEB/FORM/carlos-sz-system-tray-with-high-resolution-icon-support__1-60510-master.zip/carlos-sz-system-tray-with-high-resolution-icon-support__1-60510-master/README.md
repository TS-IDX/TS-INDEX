﻿<div align="center">

## System tray with high resolution icon support

<img src="PIC20055122138235533.gif">
</div>

### Description

System tray module with high resolution icon (Windows XP), balloon (with or without sound) and mouse event support for icon and balloon. Credits in the zip file.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2005-05-12 21:39:02
**By**             |[Carlos\-Sz](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/carlos-sz.md)
**Level**          |Beginner
**User Rating**    |5.0 (50 globes from 10 users)
**Compatibility**  |VB 6\.0
**Category**       |[Miscellaneous](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/miscellaneous__1-1.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[System\_tra1887645122005\.zip](https://github.com/Planet-Source-Code/carlos-sz-system-tray-with-high-resolution-icon-support__1-60510/archive/master.zip)








