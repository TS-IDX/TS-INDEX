﻿<div align="center">

## RadioAnn DirectShow Live Internet Radio


</div>

### Description

A live internet Radio that rests in your systray.

It is very low on CPU and Memory.

It gets it´s channels from a ini file you can edit and put your own channels in.

Observe that the channels that are in the included ini file is swedish broadband musicradio channels. I made this for my lovely wife Ann since we dont have a radio in the kitchen and she loves to listen to radio while cooking and cleaning. We got a computer in the kitchen though :-)

This InternetRadio is very straightforward, doesn´t have any fancy features, It does one thing well and that is playing Internet radio.

No graphical editor is included to edit the channels in the ini file, you need to edit it yourselve.

I am sorry but I have not commented the code, it is very few lines of code and I did not plan to show others it. The only reason I am putting it up here is because it has become popular amongs my friends so I decided to share it.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2004-01-08 20:29:28
**By**             |[Knoton](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/knoton.md)
**Level**          |Intermediate
**User Rating**    |5.0 (20 globes from 4 users)
**Compatibility**  |VB 6\.0
**Category**       |[Complete Applications](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/complete-applications__1-27.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[RadioAnn\_D172798432004\.zip](https://github.com/Planet-Source-Code/knoton-radioann-directshow-live-internet-radio__1-52813/archive/master.zip)








