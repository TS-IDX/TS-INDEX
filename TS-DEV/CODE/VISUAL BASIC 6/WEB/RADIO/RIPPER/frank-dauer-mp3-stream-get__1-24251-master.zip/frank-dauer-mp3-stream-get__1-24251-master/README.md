﻿<div align="center">

## mp3 stream get


</div>

### Description

it just connects to shoutcast or anythings like that servers and then puts the incoming data in a file
 
### More Info
 
at the moment no implementation for proxy.. (just too lazy =) ) and this whole thing isn't really much, but i haven't seen something that worked like before.. ehrm and one problem, i was too lazy to filter out the header.. but winamp, sonique and so on, just play it also.


<span>             |<span>
---                |---
**Submitted On**   |2001-06-20 13:54:58
**By**             |[Frank Dauer](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/frank-dauer.md)
**Level**          |Advanced
**User Rating**    |4.4 (31 globes from 7 users)
**Compatibility**  |VB 6\.0
**Category**       |[Sound/MP3](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/sound-mp3__1-45.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[mp3 stream214076202001\.zip](https://github.com/Planet-Source-Code/frank-dauer-mp3-stream-get__1-24251/archive/master.zip)








