Information
===========

This code uses the fmod.dll API. It can be downloaded as freeware at www.fmod.org.

MOD, IT, XM, and S3M files can be downloaded at www.modplug.com. You can find them many places elsewhere too. A lot of DOS games use this format.

The length of the song can't be displayed as there is no simple way to do that. It is almost impossible without decoding the format of the module file.

Do not wonder why there is no exit button. There is a menu.

I did not use the common dialog control as it slows things down and is a big 90KB file to disturbe for users. It is a good practice to use as less controls as posssible and use more API as it is quicker.

Do not complain about a bug if it does not run at all but instead give you an error message at the start without a number. Read the first line.