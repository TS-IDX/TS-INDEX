﻿<div align="center">

## DirectSound Stream

<img src="PIC2006116143132364.GIF">
</div>

### Description

An apporach on how to do audio streaming with DirectSound.

Supports WAV (+ ACM Codecs), MP3 and WMA.

For MP3 and WMA, you need to have WMP &gt;= 9, the WMF SDK &gt;= v9 (Google), or the WMF Redistributable ("wmfdist.exe", Google). Buffer system is pretty stable. I guess this is pretty close to Winamp's playback method.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2006-11-05 19:16:24
**By**             |[Arne Elster](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/arne-elster.md)
**Level**          |Advanced
**User Rating**    |4.9 (34 globes from 7 users)
**Compatibility**  |VB 6\.0
**Category**       |[Sound/MP3](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/sound-mp3__1-45.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[DirectSoun2029361162006\.zip](https://github.com/Planet-Source-Code/arne-elster-directsound-stream__1-66972/archive/master.zip)








