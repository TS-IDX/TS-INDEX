﻿<div align="center">

## PURE IRCd Services "Server"


</div>

### Description

Since it isnt very useful to have every Server equipped with services and link them all together i have seperated the Services from the actual Server and created another Server that only runs the Services so they become global.

It should all work very well, usually im on dill.mine.nu so why not just drop in if you have a question or whatever.

You can't use this Application as a Server for Clients, there's no port they could connect to, this "Server" has to be linked with another *real* Server. Download the real Server at:

http://pscode.com/vb/scripts/ShowCode.asp?txtCodeId=39866&lngWId=1

OR

http://dillerthekiller.free.fr/pure/ (faster)
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2002-10-22 15:57:02
**By**             |[Dennis Fisch](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/dennis-fisch.md)
**Level**          |Advanced
**User Rating**    |5.0 (10 globes from 2 users)
**Compatibility**  |VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[PURE\_IRCd\_14855610222002\.zip](https://github.com/Planet-Source-Code/dennis-fisch-pure-ircd-services-server__1-40066/archive/master.zip)








