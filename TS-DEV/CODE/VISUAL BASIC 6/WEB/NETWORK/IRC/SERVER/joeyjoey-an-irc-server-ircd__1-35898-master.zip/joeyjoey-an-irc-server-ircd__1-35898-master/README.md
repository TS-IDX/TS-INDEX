﻿<div align="center">

## an IRC SERVER \(IRCD\)

<img src="PIC20026152013409910.gif">
</div>

### Description

this is an irc server (ircd), this code is not complete if you continue this project i would like you to mail me (j23ld@hotmail.com) with your results, this is intended to be an open scource project. please vote my code if you find it useful or interesting
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2002-06-15 02:08:24
**By**             |[JoeyJoey](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/joeyjoey.md)
**Level**          |Advanced
**User Rating**    |4.4 (44 globes from 10 users)
**Compatibility**  |VB 4\.0 \(32\-bit\), VB 5\.0, VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[an\_IRC\_SER950136152002\.zip](https://github.com/Planet-Source-Code/joeyjoey-an-irc-server-ircd__1-35898/archive/master.zip)








