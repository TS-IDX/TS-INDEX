sIRC Alpha v0.11.3416
(C)2001-2001

You are using sIRC, an IRC (Internet Relay Chat) Client made for Windows.

First and foremost, you are using an ALPHA RELEASE of sIRC, therefore bugs and lack of functionality is to be expected.  I am not forcing you to use this, and recommend you do not use sIRC as your main IRC Client for the time being.  The reason I am allowing people to use these early alpha versions is in hopes of getting feedback as quick as possible.  Also, I hope that anyone using it can help me to iron out the bugs in the client as best as possible before a final version is released.  If you ever run into a bug, please inform me as soon as possible.

sIRC is my second attempt at an IRC Client.  My first client was a great learning experience and allowed me to learn what to do and what not to do when making an IRC Client. This client was started sometime in the Summer of 2001, but wasn't really developed fully until late November of 2001.  

My hope is to make a client which is ease to use, fun, and flexible.  Also, a client which is built around multiple servers.

To check for the latest release and/or updates, please visit http://sirc.ath.cx