﻿<div align="center">

## Cabral IRC Client: open source


</div>

### Description

An irc client with source code to connect to any IRC server on the net. This is a project that is open to the public and can be modified. For more information visit: http://darkimages.cjb.net
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2000-01-22 00:34:50
**By**             |[Jaime Cabral](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/jaime-cabral.md)
**Level**          |Intermediate
**User Rating**    |4.9 (39 globes from 8 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[CODE\_UPLOAD29991222000\.zip](https://github.com/Planet-Source-Code/jaime-cabral-cabral-irc-client-open-source__1-5631/archive/master.zip)








