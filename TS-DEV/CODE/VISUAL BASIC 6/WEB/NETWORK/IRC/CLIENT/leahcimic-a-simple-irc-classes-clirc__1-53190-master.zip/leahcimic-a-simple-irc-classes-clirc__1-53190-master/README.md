﻿<div align="center">

## \[A Simple\] IRC Classes \- CLIRC


</div>

### Description

CLIRC is a group of Internet Relay Chat classes which allows any programmer beginner or advanced to add IRC functionality to their programs without knowing the IRC protocol. The classes handle all the tricky stuff so you can rapidly develop IRC bots, or even a full-fledged IRC client like mIRC. Have fun and enjoy, I was reluctant to release this so please don't be reluctant to vote ;) thank you and God bless! :)
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2004-04-16 03:23:08
**By**             |[leahciMic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/leahcimic.md)
**Level**          |Advanced
**User Rating**    |4.7 (47 globes from 10 users)
**Compatibility**  |VB 3\.0, VB 4\.0 \(16\-bit\), VB 4\.0 \(32\-bit\), VB 5\.0, VB 6\.0, VB Script
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[\[A\_Simple\]1734064162004\.zip](https://github.com/Planet-Source-Code/leahcimic-a-simple-irc-classes-clirc__1-53190/archive/master.zip)








