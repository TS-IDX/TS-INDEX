################################################################
##### CLIRC - Michael Leaney                               #####
################################################################

CLIRC has been written by Michael James Leaney. CLIRC is released
as an example of IRC and can be used in your own programs. However
you must ask for my permission before using my code this is only
fair. In most cases I'd say yes but want a little recognition.

Anyway this is no where near complete even though it may look it.
Things I need to work on is Output buffer, so the client doesn't
flood the server until the server kills the client. DCC Chat and
DCC Send. 

CLIRC hasn't been tested much, theirs a few bugs I'm aware of that
I couldn't be bothered fixing right now seeing thier not serious at
all. I hope you enjoy this code, and remember it is only a quick
preview of my code. I was very reluctant to release this to the 
public, but I released it for a few reasons, 1 I wanted to see what
people think of my code, 2 I wanted to see what votes I'd get.

If you like my work please vote, then I'll start releasing more and
more of my code and keep working on this and updating it.

my email address is leahcimic@hotmail.com for any bugs, questions or
anything at all ;) 

Enjoy, and God Bless!

