﻿<div align="center">

## Winsock Basic


</div>

### Description

Learn the basics of Microsoft Winsock Control. Sending data to receiving data. Rate it excellent and you will get a surprise!
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2003-09-06 10:18:02
**By**             |[Gullu](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/gullu.md)
**Level**          |Advanced
**User Rating**    |4.3 (51 globes from 12 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Winsock\_Ba164200962003\.zip](https://github.com/Planet-Source-Code/gullu-winsock-basic__1-48307/archive/master.zip)








