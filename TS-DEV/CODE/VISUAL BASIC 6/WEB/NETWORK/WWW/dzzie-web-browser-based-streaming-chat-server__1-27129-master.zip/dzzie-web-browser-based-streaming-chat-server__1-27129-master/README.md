﻿<div align="center">

## Web Browser Based Streaming Chat Server


</div>

### Description

This is a Web browser based chat server similar to webmaze and chatropolis. Chatters wont need any special software to chat and will be able to see others posts in real time. Read the readme for full discussion. :)

Dont forget to check my sight for more stuff:

http://geocities.com/dzzie
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2001-08-19 00:41:54
**By**             |[dzzie](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/dzzie.md)
**Level**          |Intermediate
**User Rating**    |4.8 (24 globes from 5 users)
**Compatibility**  |VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[Web Browse262539102001\.zip](https://github.com/Planet-Source-Code/dzzie-web-browser-based-streaming-chat-server__1-27129/archive/master.zip)








