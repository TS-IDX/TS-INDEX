﻿<div align="center">

## FTP Server Engine \(Winsock Control\)


</div>

### Description

This latest upload has some bug fixes and greatly improves multiclient performance. I posted this code a few weeks back, that server used the Winsock API. Well after weeks of trying I had to stop due to limitations of VB. This can be done however using the Winsock control, so here is my FTP Server Engine redone using the Winsock control instead. Im sure many of you remember my old FTP server I posted here a few months back. Well this is another attempt at making a better, easier to use FTP server. You could take the server class module and drop it into any program to make it an FTP server without having to do anything inside the server. This server uses the Winsock Control. Another great feature is that the server is now event driven which makes using the server MUCH easier. This is just a demo program to show off the FTP server, I did almost no work on the user interface... The server is by no means done, probably not even usable in its current state. All it can do right now is list directories, navigate them and download files. I am still in the process of completing it. I just wanted to post it and get some feedback. Please read the first comments in the main form for more info.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2000-04-15 02:14:32
**By**             |[Matt\*](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/matt.md)
**Level**          |Advanced
**User Rating**    |4.9 (39 globes from 8 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Internet/ HTML](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/internet-html__1-34.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[CODE\_UPLOAD48164152000\.zip](https://github.com/Planet-Source-Code/matt-ftp-server-engine-winsock-control__1-7289/archive/master.zip)








