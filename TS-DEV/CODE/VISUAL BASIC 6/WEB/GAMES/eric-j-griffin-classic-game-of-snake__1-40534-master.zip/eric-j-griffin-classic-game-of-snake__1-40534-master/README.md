﻿<div align="center">

## ^^ Classic game of \~Snake\~ ^^

<img src="PIC20021181934193136.jpg">
</div>

### Description

Here is the source for the very popular, very classic game Snake. This code is very clean and fully commented. Hope you like! ... this is my first submission.
 
### More Info
 


<span>             |<span>
---                |---
**Submitted On**   |2002-11-08 23:45:30
**By**             |[Eric J\. Griffin](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByAuthor/eric-j-griffin.md)
**Level**          |Beginner
**User Rating**    |4.8 (57 globes from 12 users)
**Compatibility**  |VB 5\.0, VB 6\.0
**Category**       |[Games](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByCategory/games__1-38.md)
**World**          |[Visual Basic](https://github.com/Planet-Source-Code/PSCIndex/blob/master/ByWorld/visual-basic.md)
**Archive File**   |[^^\_Classic1494131182002\.zip](https://github.com/Planet-Source-Code/eric-j-griffin-classic-game-of-snake__1-40534/archive/master.zip)








