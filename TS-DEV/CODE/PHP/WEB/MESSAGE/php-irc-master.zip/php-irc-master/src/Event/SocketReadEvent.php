<?php

namespace Touki\IRC\Event;

class SocketReadEvent extends SocketEvent
{
}
