<?php

namespace Touki\IRC\Event;

class SocketWriteEvent extends SocketEvent
{
}
