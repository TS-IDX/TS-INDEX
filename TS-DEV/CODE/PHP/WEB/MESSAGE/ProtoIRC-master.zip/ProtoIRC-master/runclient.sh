#!/bin/bash
rlwrap -R -r -S "> " -pWhite -i -c php client.php
