<?php
$this->irc->stopic($ex[1], $msg);
?>
