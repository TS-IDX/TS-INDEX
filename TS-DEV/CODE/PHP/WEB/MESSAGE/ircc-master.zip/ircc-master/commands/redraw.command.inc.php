<?php
$this->output->HandleResize(0);
?>
