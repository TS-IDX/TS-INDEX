<?php
$this->irc->smode($ex[1], $ex[2]);
?>
