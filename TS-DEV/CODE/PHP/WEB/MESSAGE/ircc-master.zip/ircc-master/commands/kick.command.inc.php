<?php
$this->irc->skick($ex[1], $ex[2], $msgh);
?>
