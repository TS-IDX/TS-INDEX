<?php
$this->irc->snotice($ex[1], $msg);
?>
