<?php
$this->irc->sprivmsg($ex[1], implode(" ", array_slice($ex, 2)));
?>
