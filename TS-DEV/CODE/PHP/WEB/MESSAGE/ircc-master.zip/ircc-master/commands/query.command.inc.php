<?php
// XXX find buffer by name and go to it
$this->output->AddBuffer($ex[1]);
?>
