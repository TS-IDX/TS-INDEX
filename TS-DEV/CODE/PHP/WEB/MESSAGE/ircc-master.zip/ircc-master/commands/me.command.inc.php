<?php
$this->irc->saction($msgf);
?>
