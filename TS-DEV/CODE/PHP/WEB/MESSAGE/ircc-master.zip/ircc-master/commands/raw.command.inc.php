<?php
$this->irc->sendline($msgf);
?>
