=========================
= PITC v1.0 Development =
=========================

What is PITC?
-------------
PITC is an OpenSource PHP IRC client, coded
entirely in PHP along with a coding api and
simplicity to boot. Intended for people whom
need a simple IRC Client and fast or those
who simply need to make IRC bots quickly and
not need to worry about stability or gaping
flaws in code.

What does PITC require?
-----------------------
PITC merely requires a bare bones PHP install
of version 5 or above.
Most VPS' or Mac systems come with PHP preinstalled
so users needn't worry.

What Operating Systems has PITC been tested on?
-----------------------------------------------
PITC has been tested on Ubuntu, Debian, Mac OSX
and Windows, It merely failed on Windows due to
windows lacking certain requirements. A windows
ready version should be available soon.

PITC is Opensource! I'm going to steal it and call it my own!
-------------------------------------------------------------
No you're not. PITC is OpenSource but you HAVE to give credit
if you decide to fork and create your own client from PITC,
this code has been created by myself (Thomas Edwards) and is
my own work not yours! It currently IS on GIT so it will start
to comprimise of other peoples work. Credit those where needed!
