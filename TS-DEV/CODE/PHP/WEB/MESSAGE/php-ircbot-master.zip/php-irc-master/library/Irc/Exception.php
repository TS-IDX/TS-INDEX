<?php

namespace Irc;

class Exception extends \Exception {}