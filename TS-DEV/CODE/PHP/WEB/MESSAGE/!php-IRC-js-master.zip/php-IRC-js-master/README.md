# php-IRC-js

##IRC client (PHP - Javascript)

### Dependency
none

### Settings
Edit in connect.php

$ircServer = "irc.freenode.net";

$ircPort = "6667";

$ircChannel = "#KERNEL_ULTRAS";

$ircUser = "KU-bot";

$ircNick = "KU-bot";

$ircRealName = "KU-bot";

### Licence
[GNU GPLv2](http://www.gnu.org/licenses/gpl-2.0.html)

![php-IRC-js](https://raw.githubusercontent.com/bedna-KU/php-IRC-js/master/screenshot/screenshot.jpg)
