<?php
namespace Buttress\IRC\Message;

class PingMessage extends GenericMessage
{

}
