<?php
use Buttress\IRC\Message\MessageFactory;

class MessageFactoryTest extends \PHPUnit_Framework_TestCase
{

    public function testRegister()
    {
        $factory = new MessageFactory();
        $id = uniqid();

        $factory->register(
            'TEST',
            function () use ($id) {
                return $id;
            });

        $this->assertEquals($id, $factory->make('TEST'));
    }

    public function testDeconstructRaw()
    {
        $raw = ":prefix TEST param1 param2 :some long param";
        $deconstructed = array(
            'prefix',
            'TEST',
            array('param1', 'param2', 'some long param'));

        $factory = new MessageFactory();
        $this->assertEquals($deconstructed, $factory->deconstructRaw($raw));
    }

    public function testConstructPrivmsg()
    {
        $factory = new MessageFactory();

        $this->assertInstanceOf('\Buttress\IRC\Message\PrivmsgMessage', $factory->make('privmsg'));
    }

    public function testConstructPing()
    {
        $factory = new MessageFactory();

        $this->assertInstanceOf('\Buttress\IRC\Message\PingMessage', $factory->make('ping'));
    }

}
