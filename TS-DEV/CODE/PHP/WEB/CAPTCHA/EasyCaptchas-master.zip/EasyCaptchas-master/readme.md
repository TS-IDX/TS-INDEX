# Easy Captchas
Generate image with string code to validate and add to web page.
Initiated for university learning and source code sharing.

# Configuration
- Captcha image size depend on the initialy loaded .png image
- Font served by the loaded one
- Set the digit number, size, spacement and position of the text

# Requirement
- PHP 7.0
- PNG output