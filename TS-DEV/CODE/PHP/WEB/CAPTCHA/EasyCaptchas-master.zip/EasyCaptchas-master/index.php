<?php
/* frontal controller
* create a captcha image in php with random generated string to validate */

echo "
<!DOCTYPE html>
<html>
  <head>
    <title>Easy Captchas Generator</title>
  </head>
  <body>

    <img src='script-captchas.php' alt='captchas' />

    <br />

    <a href=''>refresh</a>
    
  </body>
</html>";

?>