# PCaptcha
A simple/lightweight class provides you with the necessary tools to generate a friendly/secure captcha and validate it 

![alt tag](https://raw.githubusercontent.com/phpfalcon/PCaptcha/master/captcha.png) 
