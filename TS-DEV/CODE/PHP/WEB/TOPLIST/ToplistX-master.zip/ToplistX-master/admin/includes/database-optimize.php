<script language="JavaScript">
$(function()
  {
      $('#notice').show();
      $('#info').hide();
      $('#activity').hide();
  });
</script>

<img src="images/activity.gif" id="activity" style="padding-left: 10px; padding-top: 10px;">
<div id="notice" style="display: none; padding: 10px;">
<div class="notice">The database has been repaired and optimized successfully</div>
</div>
<div id="info" style="padding: 10px;">
