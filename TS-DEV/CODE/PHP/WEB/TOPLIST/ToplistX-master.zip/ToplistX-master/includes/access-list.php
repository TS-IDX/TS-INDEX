<?php
// Uncomment the next line and enter your IP address(es) or hostname(s)
//$allowed_ips = array('');
?>