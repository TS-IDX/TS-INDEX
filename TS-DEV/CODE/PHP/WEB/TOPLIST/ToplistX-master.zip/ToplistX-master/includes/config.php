<?PHP
$C = array();
?>