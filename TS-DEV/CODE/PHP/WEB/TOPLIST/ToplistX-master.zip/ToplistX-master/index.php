<?php
header('Location: accounts.php');
?>