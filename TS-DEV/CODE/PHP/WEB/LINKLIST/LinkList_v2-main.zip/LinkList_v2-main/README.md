Linklist
================

This is the new codeQuake Linklist-Software based on WoltLab Community Framework 2.0.

[![Build Status](https://travis-ci.org/codeQuake/LinkList_v2.svg?branch=master)](https://travis-ci.org/codeQuake/LinkList_v2)


Contributions
----------------
If you want to support the development, you are allowed to use pull requests. But please test your changes before submitting the commit. Thank you!


License
----------------
All files are LGPL licensed:
GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
