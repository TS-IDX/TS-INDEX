<?php
require_once ('./global.php');
wcf\system\request\RequestHandler::getInstance()->handle('linklist');
