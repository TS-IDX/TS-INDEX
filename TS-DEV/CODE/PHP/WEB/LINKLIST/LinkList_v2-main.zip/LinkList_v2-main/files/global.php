<?php
// include config
require_once (dirname(__FILE__) . '/config.inc.php');

// include wcf
require_once (RELATIVE_WCF_DIR . 'global.php');
