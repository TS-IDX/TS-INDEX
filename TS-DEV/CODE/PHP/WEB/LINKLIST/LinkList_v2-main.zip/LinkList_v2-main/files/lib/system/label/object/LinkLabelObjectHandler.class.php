<?php
namespace linklist\system\label\object;

use wcf\system\label\object\AbstractLabelObjectHandler;

class LinkLabelObjectHandler extends AbstractLabelObjectHandler {

	protected $objectType = 'de.codequake.linklist.link';
}
