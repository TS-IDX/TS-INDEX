<?php
namespace linklist\data\link;

use wcf\data\DatabaseObjectDecorator;

class ViewableLink extends DatabaseObjectDecorator {

	protected static $baseClass = 'linklist\data\link\Link';
}
