<?php
// define paths
define('RELATIVE_LINKLIST_DIR', '../');

// include config
require_once (dirname(dirname(__FILE__)) . '/config.inc.php');

// include WCF
require_once (RELATIVE_WCF_DIR . 'acp/global.php');
