# LinkList-easy
LinkList easy
